<?php
declare (strict_types = 1);

namespace app\admin\controller;

use think\facade\Cache;
use think\facade\Env;
use think\facade\Db;
use think\facade\View;
use app\common\builder\ZBuilder;
use app\user\model\User as UserModel;


/**
 * 后台默认控制器
 * @package app\admin\controller
 */
class Index extends Admin
{
    /**
     * 后台首页
     * @author 蔡伟明 <314013107@qq.com>
     * @return string
     */
    public function index()
    {
        $admin_pass = Db::name('admin_user')->where('id', 1)->value('password');

        if (UID == 1 && $admin_pass && \Hash::check('admin', $admin_pass)) {
            View::assign('default_pass', 1);
        }
        return View::fetch();
    }

    /**
     * 清空系统缓存
     * @author 蔡伟明 <314013107@qq.com>
     */
    public function wipeCache()
    {
        $wipe_cache_type = config('app.wipe_cache_type');
        if (!empty($wipe_cache_type)) {
            foreach ($wipe_cache_type as $item) {
                switch ($item) {
                    case 'TEMP_PATH':
                        array_map('unlink', glob(Env::get('runtime_path'). 'temp/*.*'));
                        break;
                    case 'LOG_PATH':
                        $dirs = (array) glob(Env::get('runtime_path') . 'log/*');
                        foreach ($dirs as $dir) {
                            array_map('unlink', glob($dir . '/*.log'));
                        }
                        array_map('rmdir', $dirs);
                        break;
                    case 'CACHE_PATH':
                        array_map('unlink', glob(Env::get('runtime_path'). 'cache/*.*'));
                        break;
                }
            }
            Cache::clear();
            $this->success('清空成功');
        } else {
            $this->error('请在系统设置中选择需要清除的缓存类型');
        }
    }

    /**
     * 个人设置
     * @author 蔡伟明 <314013107@qq.com>
     */
    public function profile()
    {
        // 保存数据
        if ($this->request->isPost()) {
            $data = $this->request->post();

            $data['nickname'] == '' && $this->error('昵称不能为空');
            $data['id'] = UID;

            // 如果没有填写密码，则不更新密码
            if ($data['password'] == '') {
                unset($data['password']);
            }

            $UserModel = new UserModel();
            if ($user = $UserModel->allowField(['nickname', 'email', 'password', 'mobile', 'avatar'])->update($data)) {
                // 记录行为
                action_log('user_edit', 'admin_user', UID, UID, get_nickname(UID));
                $this->success('编辑成功');
            } else {
                $this->error('编辑失败');
            }
        }

        // 获取数据
        $info = UserModel::where('id', UID)->field('password', true)->find();

        // 使用ZBuilder快速创建表单
        return ZBuilder::make('form')
            ->addFormItems([ // 批量添加表单项
                ['static', 'username', '用户名', '不可更改'],
                ['text', 'nickname', '昵称', '可以是中文'],
                ['text', 'email', '邮箱', ''],
                ['password', 'password', '密码', '必填，6-20位'],
                ['text', 'mobile', '手机号'],
                ['image', 'avatar', '头像']
            ])
            ->setFormData($info) // 设置表单数据
            ->fetch();
    }

    /**
     * 检查版本更新
     * @author 蔡伟明 <314013107@qq.com>
     * @return \think\response\Json
     * @throws \think\db\exception\BindParamException
     * @throws \think\exception\PDOException
     */
    public function checkUpdate()
    {
        $params                    = config('dolphin.');
        $params['domain']          = request()->domain();
        $params['website']         = config('app.web_site_title');
        $params['ip']              = $_SERVER['SERVER_ADDR'];
        $params['php_os']          = PHP_OS;
        $params['php_version']     = PHP_VERSION;
        $params['mysql_version']   = Db::query('select version() as version')[0]['version'];
        $params['server_software'] = $_SERVER['SERVER_SOFTWARE'];
        $params                    = http_build_query($params);

        $opts = [
            CURLOPT_TIMEOUT        => 3,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_URL            => config('dolphin.product_update'),
            CURLOPT_USERAGENT      => $_SERVER['HTTP_USER_AGENT'],
            CURLOPT_POST           => 1,
            CURLOPT_POSTFIELDS     => $params
        ];

        // 初始化并执行curl请求
        $ch = curl_init();
        curl_setopt_array($ch, $opts);
        $data  = curl_exec($ch);
        curl_close($ch);

        if($data === false){
        	return json([
                'update' => '',
                'auth'   => '暂无授权',
            ]);
        }
        $result = json_decode($data, true);

        if ($result['code'] == 1) {
            return json([
                'update' => '<a class="badge badge-primary" href="http://www.dolphinphp.com/download" target="_blank">有新版本：'.$result["version"].'</a>',
                'auth'   => $result['auth']
            ]);
        } else {
            return json([
                'update' => '',
                'auth'   => $result['auth']
            ]);
        }
    }
}
